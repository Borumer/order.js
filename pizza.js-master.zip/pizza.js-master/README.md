# pizza.js

A program in which you take an order with the arguments including topping, curst type, and size. The price is calculated.

