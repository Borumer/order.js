window.onload = function() {
	document.querySelector(".site-footer").innerHTML += '<span class = "site-footer-disclaimer">Disclaimer: Food not delivered</span>';
}
